# Project Overview
The Electric Car Sales & Charging Station Trends Analysis project is designed to help visualize and understand the trends in electric vehicle adoption and the growth of supporting charging infrastructure. By analyzing data from 2011 to 2021, this project tracks key metrics such as electric car sales, the number of charging stations, charging points, and connection power across various years.

The goal of the project is to offer insights into how electric vehicle adoption correlates with the expansion of charging stations, thus assisting businesses, policymakers, and energy providers in making informed decisions about the future of the electric vehicle market and infrastructure development.

# Project Structure:
This project is organized into the following key folders and components:

backend/:

Contains the server and logic for importing, storing, and handling the data. It connects to a MongoDB database and provides an interface for data storage.
models/: Defines the data schema (e.g., for YearlyTrends), representing the structure of the data stored in the MongoDB database.
importing/: A script for importing the CSV data (yearly_trends.csv) into MongoDB.
config/: Contains configuration files (e.g., for connecting to the database).
visual/:

Houses the Python scripts used for data visualization and analysis.
config/: A file that contains database connection settings and data handling configurations.
utils/: Helper functions for data processing and visualization.
visualisations/: Includes the actual visualizations generated from the data, such as charts and reports.
warehouse/:

Contains the raw data files (e.g., CSVs) used for analysis and visualization.

# Project Steps
The project is divided into several phases to ensure proper data management, processing, and visualization:


## Main Implemented Phases in the Database
1. Data Gathering & Import
CSV File: Data was gathered from a CSV file (yearly_trends.csv) that contains information on electric car sales, commissioning years, charging stations, charging points, and connection power from 2011 to 2021.
MongoDB: The data was imported into a MongoDB database (backend), which serves as the central data storage for the project.
2. Data Preparation (ETL)
The CSV data was cleaned, parsed, and transformed (ETL) to match the structure of the MongoDB database.
Using the csv-parser library, the CSV rows were read and stored as documents in the YearlyTrends collection in the MongoDB database.
3. Data Storage & Modeling
The database schema was designed with a focus on storing time-series data (e.g., year, electric car sales, charging stations) in a structured way.
The MongoDB insertMany method was used to insert bulk data into the collection efficiently.
4. Data Analysis & Visualization
Python, along with libraries like matplotlib, was used for data visualization.
The main chart plotted the relationship between electric car sales and charging stations over the years, helping to understand the correlation between these two metrics.
Visuals were saved and displayed for further reporting and presentation.

## Problems Solved:
Data Importing: One of the challenges was properly importing and transforming the CSV data into the desired format for MongoDB, especially handling potential parsing errors and ensuring data consistency.
Database Connectivity: Ensuring a stable connection to MongoDB was crucial for successful data insertion. Proper error handling was implemented to address connection issues.
Visualization: Generating clear and insightful visualizations of the data required proper data cleaning and filtering. Adjustments to plot styles (e.g., axis rotation, legend placement) were made to ensure clarity.
Possible Enhancements:
Enhanced Visualizations: Future enhancements could include more detailed interactive charts using libraries like Plotly or integrating real-time data updates to dynamically track new trends.
Additional Data Sources: Other datasets (e.g., government reports, sales projections, etc.) can be integrated into the analysis to further improve insights.
Machine Learning: Implementing machine learning algorithms for predictive analysis on electric car sales or charging station deployments could add significant value.


# Use cases
This project has successfully enabled the import, analysis, and visualization of trends related to electric car sales and charging infrastructure. The data-driven approach provides valuable insights for businesses and stakeholders in the electric vehicle industry and green energy initiatives.



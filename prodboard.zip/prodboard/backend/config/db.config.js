module.exports = {
    url: 'mongodb://localhost:27017/backend'
}

// When deployed later on, this needs to be loaded from a .env file